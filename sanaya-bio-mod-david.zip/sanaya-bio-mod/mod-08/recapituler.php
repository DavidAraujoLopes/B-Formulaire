<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Contact Sanaya Bio</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <style>
    
    </style>
</head>
<body>
    <h2>Formulaire de Contact</h2>
    <form action="traitement_formulaire.php" method="POST">
        <label>Civilité :</label>
        <select name="civilite">
            <option value="M.">M.</option>
            <option value="Mme">Mme</option>
            <option value="Mlle">Mlle</option>
        </select><br/><br/>

        <label>Nom :</label>
        <input type="text" name="nom" required><br/><br/>

        <label>Prénom :</label>
        <input type="text" name="prenom" required><br/><br/>

        <label>Téléphone :</label>
        <input type="tel" name="telephone" required><br/><br/>

        <label>Email :</label>
        <input type="email" name="email" required><br/><br/>

        <label>Raison du contact :</label>
        <select name="raison">
            <option value="renseignement">Renseignement</option>
            <option value="reclamation">Réclamation</option>
            <option value="commande">Commande</option>
        </select><br/><br/>

        <label>Mode de réponse :</label><br/>
        <input type="checkbox" name="reponse[]" value="email"> Email<br/>
        <input type="checkbox" name="reponse[]" value="sms"> SMS<br/>
        <input type="checkbox" name="reponse[]" value="telephone"> Téléphone<br/><br/>

        <label>Date de rappel (si applicable) :</label>
        <input type="date" name="date_appel"><br/><br/>

        <label>Message :</label><br/>
        <textarea name="message" rows="4" cols="50"></textarea><br/><br/>

        <input type="submit" value="Envoyer">
        <input type="reset" value="Réinitialiser">
    </form>
</body>
</html>
php
<?php

$civilites = array("M." => "Monsieur", "Mme" => "Madame", "Mlle" => "Mademoiselle");
$raison_contact = array("renseignement" => "Renseignement", "reclamation" => "Réclamation", "commande" => "Commande");
$mode_reponse = array("email" => "Par email", "sms" => "Par SMS", "telephone" => "Par téléphone");


$nom = $prenom = $telephone = $email = $raison = $modes_reponse = $date_rappel = $message = "";
$errors = array();


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST["nom"])) {
        $errors[] = "Le champ nom est obligatoire.";
    } else {
        $nom = test_input($_POST["nom"]);
    }

    if (empty($_POST["prenom"])) {
        $errors[] = "Le champ prénom est obligatoire.";
    } else {
        $prenom = test_input($_POST["prenom"]);
    }

    if (empty($_POST["telephone"])) {
        $errors[] = "Le champ téléphone est obligatoire.";
    } else {
        $telephone = test_input($_POST["telephone"]);
    }

?>