<!DOCTYPE html>
<html lang="fr">
    <head>
        <title>Sanaya</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    </head>
    <body>
		
		<fieldset>
			<legend>Recherche d'un produit</legend>
			
			<form action="rechercher-produit.php" method="GET">
			
				<label>Saisir le nom produit :</label>
				<input type="text" name="nomProduit" placeholder="Nom du produit" />
				
				<br/>
				
				<input type="submit" value="Valider" /> 
			
			</form>

		</fieldset>
		
	</body>
</html>
php
<!DOCTYPE html>

<?php

	$produitsDisponibles = array(
			
			'Ahibero' ,
			'Ajowan' ,
			'Amande' , 
			'Amiris' ,
			'Aneth'
		) ;
		
	$nomProduit = ucfirst( $_GET[ 'nomProduit' ] ) ;

?>


<html lang="fr">
    <head>
        <title>Sanaya</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    </head>
    <body>
		
		Le produit <strong><?php echo $nomProduit ; ?></strong> est
		
		<?php if( in_array( $nomProduit , $produitsDisponibles ) ) {?>
			disponible.
		<?php } else {?>
			indisponible.
		<?php } ?>
		
		
	</body>
</html>