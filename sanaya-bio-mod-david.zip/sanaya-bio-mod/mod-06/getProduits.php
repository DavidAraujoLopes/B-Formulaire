<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Sanaya</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<body>
    <fieldset>
        <legend>Produits par catégorie</legend>

        <form action="getProduits.php" method="GET" >

            <label for="categorie">Catégorie :</label>
            <br/>
            <select id="categorie" name="categorie">
                <option value="hl-ess">Huiles Essentielles</option>
                <option value="mcrt-hlx">Macérâts Huileux</option>
                <option value="ext-plnt">Extraits de Plantes</option>
                <option value="argl">Argiles</option>
            </select>
            <br/>
            <input type="submit" value="Valider" />
            <input type="reset" value="Réinitialiser" />
        </form>


    </fieldset>

</body>

</html>
php
<?php
$lesProduits = array(
    array("nom" => "Ahibero", "categorie" => "hl-ess"),
    array("nom" => "Ail", "categorie" => "hl-ess"),
    array("nom" => "Ajowan", "categorie" => "hl-ess"),
    array("nom" => "Amande", "categorie" => "hl-ess"),
    array("nom" => "Amyrio", "categorie" => "hl-ess"),
    array("nom" => "Calendula", "categorie" => "mcrt-hlx"),
    array("nom" => "Millepertuis", "categorie" => "mcrt-hlx"),
    array("nom" => "Macadamia", "categorie" => "mcrt-hlx"),
    array("nom" => "Arnica", "categorie" => "mcrt-hlx"),
    array("nom" => "Ginkgo Biloba", "categorie" => "ext-plnt"),
    array("nom" => "Guarana", "categorie" => "ext-plnt"),
    array("nom" => "Moringa", "categorie" => "ext-plnt"),
    array("nom" => "Prêle", "categorie" => "ext-plnt"),
    array("nom" => "Blanche", "categorie" => "argl"),
    array("nom" => "Illite verte", "categorie" => "argl"),
    array("nom" => "Montmorillonite", "categorie" => "argl")
);

$lesCategories = array(
    "hl-ess" => "Huiles Essentielles",
    "mcrt-hlx" => "Macérâts Huileux",
    "ext-plnt" => "Extraits de Plantes",
    "argl" => "Argiles"
);

$categorie = $_GET['categorie'] ?? 'hl-ess'; 
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Sanaya</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<body>
    <h3>Produits de catégorie <?php echo $lesCategories[$categorie]; ?>:</h3>
    <ul>
        <?php
        foreach ($lesProduits as $unProduit) {
            if ($unProduit['categorie'] == $categorie) {
                echo "<li>" . $unProduit['nom'] . "</li>";
            }
        }
        ?>
    </ul>
    <a href="index.html">Retour au formulaire</a>
</body>
</html>