<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Sanaya</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<body>
    <fieldset>
        <legend>Authentification</legend>
        
        <form action="seConnecter.php" method="POST" name="authentification">
   
            <label>Nom de connexion :</label>
            <input type="text" name="nomConnexion" />
            
            <br/>
                        
            <label>Mot de passe :</label>
            <input type="password" name="motDePasse" />
            
            <br/>

            <input type="submit" value="Valider" />
            <input type="reset" value="Réinitialiser" />

        </form>
        
    </fieldset>
</body>
</html>




php

<?php
    $connexionOk = FALSE ;
    if(isset($_POST['nomConnexion']) && isset($_POST['motDePasse'])) {
        $nomConnexion = $_POST['nomConnexion'];
        $motDePasse = $_POST['motDePasse'];

        if($nomConnexion === 'sanaya' && $motDePasse === 'bio') {
            $connexionOk = TRUE ;
        }
    }
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Sanaya</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<body>
    <h5>
        <?php
            if($connexionOk) {
                echo "Administrateur connecté." ;
            } else {
                echo "Connexion refusée." ;
            }
        ?>
    </h5>

    <?php
        if($connexionOk) {
            echo '<a href="deconnexion.php">Déconnexion</a>' ;
        } else {
            echo '<a href="authentification.html">Retour au formulaire</a>' ;
        }
    ?>
</body>
</html>